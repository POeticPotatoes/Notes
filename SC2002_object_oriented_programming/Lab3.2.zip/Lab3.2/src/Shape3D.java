public interface Shape3D extends Shape {
    public double getVolume();
}
